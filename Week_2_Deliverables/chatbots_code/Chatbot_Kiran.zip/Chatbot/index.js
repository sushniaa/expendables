const express = require('express');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');
const dotenv = require('dotenv').config();
const path = require('path');
const multer = require('multer'); // For handling file uploads
const fs = require('fs').promises; // For reading the uploaded file

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());

// Set up multer for file uploads
const upload = multer({ dest: 'uploads/' }); // Temporary storage for uploaded files

const MODEL_NAME = "gemini-1.5-flash";
const API_KEY = process.env.API_KEY;

async function runChat(userInput, imagePath = null) {
  const genAI = new GoogleGenerativeAI(API_KEY);
  const model = genAI.getGenerativeModel({ model: MODEL_NAME });

  const generationConfig = {
    temperature: 0.9,
    topK: 1,
    topP: 1,
    maxOutputTokens: 1000,
  };

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
  ];

  const chat = model.startChat({
    generationConfig,
    safetySettings,
    history: [
      {
        role: "user",
        parts: [{ text: "You are an agriculture expert assistant named AgriBot. Only provide information related to agriculture, such as crops, harvests, plant diseases, soil management, etc. Politely refuse to answer any unrelated questions." }],
      },
      {
        role: "model",
        parts: [{ text: "Hello! I'm AgriBot, your agriculture assistant. How can I help you today?" }],
      },
    ],
  });

  // Prepare the message parts
  const messageParts = [{ text: userInput }];

  // If an image is provided, convert it to base64 and add it to the message
  if (imagePath) {
    const imageData = await fs.readFile(imagePath);
    const base64Image = imageData.toString('base64');
    messageParts.push({
      inlineData: {
        data: base64Image,
        mimeType: 'image/jpeg', // Adjust based on the image type if needed
      },
    });
  }

  const result = await chat.sendMessage(messageParts);
  return result.response.text();
}

app.get('/', (req, res) => {
  const filePath = path.join(__dirname, 'index.html');
  res.sendFile(filePath, (err) => {
    if (err) {
      console.error('Error sending index.html:', err);
      res.status(500).json({ error: 'Failed to load the chat interface' });
    }
  });
});

// Update the /chat endpoint to handle both text and image uploads
app.post('/chat', upload.single('image'), async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    const image = req.file; // Uploaded image file

    if (!userInput && !image) {
      return res.status(400).json({ error: 'Please provide a message or an image' });
    }

    const imagePath = image ? image.path : null;
    const response = await runChat(userInput || "Analyze this image for agriculture-related insights.", imagePath);

    // Clean up the uploaded file if it exists
    if (imagePath) {
      await fs.unlink(imagePath).catch(err => console.error('Error deleting file:', err));
    }

    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});